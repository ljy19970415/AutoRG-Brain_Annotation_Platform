import logging
import os
import sys
import time
import datetime
import random

from flask import Flask, request, Response, jsonify
from flask_cors import CORS
import sys
import json



### settings -----------------------------------------------------------

JSON_PATH = "/tag_data/data/user" # 输入数据
DONE_PATH = "/tag_data/data/done" # 输出数据
DOING_PATH = "/tag_data/data/doing" # 中间结果

# 添加用户
user_set = set([f"user{i}" for i in range(1, 201)])
paswd = "pwd333"


### initial -----------------------------------------------------------


app = Flask(__name__)
CORS(app, resources=r'/*')

logging.basicConfig(level=logging.INFO)


u_id = 1



### util function start-----------------------------------------------------------

def merge_two_dicts(x, y):
    """Given two dictionaries, merge them into a new dict as a shallow copy."""
    z = x.copy()
    z.update(y)
    return z


def err_message(err_str):
    yield f"event: error\ndata: {err_str}\n\n"
    yield "event: error\ndata: [DONE]\n\n"

def read_json_file(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def write_json_file(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4, ensure_ascii=False)
    os.chmod(file_path, 0o777)

def wrap_err_result(msg, code=500):
    # return jsonify({"code": code, "msg": msg})
    return jsonify({"code": 0, "msg": msg})


def wrap_result(data):
    # return jsonify({"code": 200, "data": data})
    # print(data)
    return jsonify({"code": 1, "data": data})


err = wrap_err_result
fail = wrap_err_result
ok = wrap_result

### util function end-----------------------------------------------------------

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        username = request.json.pop("username")
        password = request.json.pop("password")
    except Exception as e:
        app.logger.exception(f"ARGS ERROR, EXCEPTION: {e}")
        return jsonify({"code": 0, "msg": "请求参数异常"})

    if not username or not password:
        return jsonify({"code": 0, "msg": "用户名、密码不能为空"})
    elif username not in user_set:
        return jsonify({"code": 0, "msg": "找不到用户"})
    elif password != paswd:
        return jsonify({"code": 0, "msg": "账号或密码有误, 请重新输入"})

    data = dict()
    data["uid"] = int(username[4:])
    data["token"] = "mhrawvjnsyn1as3ps1u143oi0u9orqrc6k9947rn"
    data["username"] = username

    return jsonify({"code": 1, "data": data, "msg": "登录成功"})




# 获取会话内容
@app.route("/api/conv/case/<username>/<cid>", methods=['GET'])
def conv(username, cid):
    app.logger.info(f"id:{cid}")
    def get_by_id(username, cid):
        file_path = os.path.join(DONE_PATH, f"{username}", f"{cid}.json")
        if not os.path.exists(file_path):
            file_path = os.path.join(DOING_PATH, f"{username}", f"{cid}.json")
            if not os.path.exists(file_path):
                file_path = os.path.join(JSON_PATH, f"{username}", f"{cid}.json")
                if not os.path.exists(file_path):
                    return None
        res = read_json_file(file_path)
        return res

    try:
        conversation = get_by_id(username, cid)
        if conversation is None:
            return err("对话不存在")
        else:
            return ok(conversation["convs"])
    except Exception as e:
        app.logger.exception(f"文件读取失败: {e}")
        return err("文件读取失败")


# 生成回复
@app.route("/api/conv/answer/<username>/<cid>", methods=['POST'])
def chat(username, cid):
    try:
        answer = request.json.pop("answer")
    except Exception as e:
        app.logger.exception(f"ARGS ERROR, EXCEPTION: {e}")
        return jsonify({"code": 0, "msg": "请求参数异常"})

    json_file_path = os.path.join(JSON_PATH, f"{username}", f"{cid}.json")
    doing_file_path = os.path.join(DOING_PATH, f"{username}", f"{cid}.json")
    done_file_path = os.path.join(DONE_PATH, f"{username}", f"{cid}.json")

    res = read_json_file(json_file_path)
    res["convs"][0]["answer"] = [answer]


    write_json_file(res, done_file_path)


    return jsonify({"code": 1, "msg": "success"})


# 获取话题列表
@app.route("/api/conv/list/<username>", methods=['GET'])
def chat_get_list(username):

    def get_list_by_uid(username):
        data = []
        json_files = [file for file in os.listdir(os.path.join(JSON_PATH, f"{username}")) if file.endswith('.json')]
        done_files = [file for file in os.listdir(os.path.join(DONE_PATH, f"{username}")) if file.endswith('.json')]

        done_list = done_files
        undone_list = []

        undone_list = set(json_files) - set(done_files)
        total_list = sorted(list(json_files))
        app.logger.info(f"{DONE_PATH}, {done_list}, {JSON_PATH}, {undone_list}")
        for i in total_list:
            title = i.split(".json")[0]
            title_flag = title
            if i in undone_list:
                title_flag = ""
            data += [{
                        "title": title,
                        "titleTime": title_flag,
                        "_id": title
                    }]
        return data

    conversation = get_list_by_uid(username)
    return ok(conversation)
    pass


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=10111)
